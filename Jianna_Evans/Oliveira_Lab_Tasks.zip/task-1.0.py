"""
May be easier to run in .ipynb file as julia needs to be installed to run
"""

import numpy as np
# install julia / pip install diffeqpy
from diffeqpy import de
import matplotlib.pyplot as plt


# define model
def model_dde(u, h, p, t):
    # parameters are unpacked
    tau, c1, c2, c3, c4 = p

    # [A, B] are a vector to the current state u
    A, B = u

    # delayed state is retrieved from the history function h()
    # h returns the full vector [A, B] at time (t-tau)
    # diffeqpy makes decision one whether to use initial values or calculate time delayed values
    A_tau, B_tau = h(p, t - tau)

    # defined differential equations
    dA_dt = c1 - c3 * A * B
    dB_dt = c2 * A_tau - c4 * B

    return [dA_dt, dB_dt]


# history function utilized by diffeqpy (defines A, B at time t)
def h(p, t):
    # initial values for A and B
    return [10.0, 200.0]


# define time period as a tuple
tspan = (0.0, 1000.0)
tau = 50.0  # define time delay
# define parameters utilized in model in tuple
p = (tau, 20.0, 0.1, 0.1, 0.1)  # (tau, c1, c2, c3, c4)

# gives starting values of A and B in array
u0 = [10.0, 200.0]  # Starting values at t=0

# initilizes DDE problem with given parameters
prob = de.DDEProblem(model_dde, u0, h, tspan, p, constant_lags=[tau])

# solves DDE problem
sol = de.solve(prob, de.MethodOfSteps(de.Tsit5()))  # Tsit5() is standard non-stiff solver

# values from DDE solver are extracted into arrays
t = np.array(sol.t)
u_res = np.stack(sol.u)  # used stack instead of np.array to yield 2D matrix [A, B]

# slice 2D matrix for individual plot lines
plt.plot(t, u_res[:, 0], label='A', color='teal')
plt.plot(t, u_res[:, 1], label='B', color='orange')


plt.title('Negative Feedback System (A & B) (Tau = 50)')
plt.xlabel('Time')
plt.ylabel('Value')
plt.legend()
plt.grid(True, alpha=0.3)
plt.show()