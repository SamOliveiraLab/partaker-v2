import numpy as np
# install julia / pip install diffeqpy
from diffeqpy import de
import matplotlib.pyplot as plt


def model_dde(u, h, p, t):
    tau, c1, c2, c3, c4 = p
    A, B = u
    A_tau, B_tau = h(p, t - tau)

    dA_dt = c1 - c3 * A * B
    dB_dt = c2 * A_tau - c4 * B

    return [dA_dt, dB_dt]


def h(p, t):
    return [10.0, 200.0]


u0 = [10, 200]
tspan = (150.0, 1000.0)

# different tau values for comparison
taus = [10.0, 50.0, 75.0, 100.0]
# split figures into subplots with linked horizontal axes
fig, axs = plt.subplots(len(taus), 1, figsize=(10, 8), sharex=True)

for i, tau_val in enumerate(taus):
    # solve DDE with current time delay tau
    p = (tau_val, 20.0, 0.1, 0.1, 0.1)
    prob = de.DDEProblem(model_dde, u0, h, tspan, p, constant_lags=[tau_val])
    sol = de.solve(prob, de.MethodOfSteps(de.Tsit5()))

    # values are extracted from DDE solver for current tau
    t_vals = np.array(sol.t)
    u_res = np.stack(sol.u)

    # specific subplot for current tau value is plotted
    axs[i].plot(t_vals, u_res[:, 0], label='A', color='teal')
    axs[i].plot(t_vals, u_res[:, 1], label='B', color='orange')
    axs[i].set_title(f"Tau = {tau_val}")
    axs[i].legend(loc='upper right')
    axs[i].grid(True, alpha=0.3)

plt.xlabel("Time")
plt.tight_layout()
plt.show()
