import torch
import torchvision
from torch.utils.data import Dataset
import torchvision.transforms as transforms
import torch.nn.functional as functional
import matplotlib.pyplot as plt

# put sobel filter on image
def sobel_filter(img_tensor):
    # add additional 'batch' dimension for to pass through nn.functional
    input_tensor = img_tensor.unsqueeze(0)  # [1, 1, 32, 32]

    # define convolutional kernel and set tensor device on input tensor image
    device = img_tensor.device
    # view is in format (channel_out, channel_in, kernel_height, kernel_width)
    kx = torch.tensor([[-1., 0., 1.], [-2., 0., 2.], [-1., 0., 1.]], device=device).view(1, 1, 3, 3)
    ky = torch.tensor([[-1., -2., -1.], [0., 0., 0.], [1., 2., 1.]], device=device).view(1, 1, 3, 3)


    # padding = 1 to add 1 pixel border around image during convolution, preserves original image shape
    px = functional.conv2d(input_tensor, kx, padding=1)
    py = functional.conv2d(input_tensor, ky, padding=1)

    # calculations for magnitude and magnitude normalization
    magnitude = torch.sqrt(px ** 2 + py ** 2)
    # min-max scaling equation utilized to map values to range [0,1]
    # epsilon value 1e-8 used to prevent division error if pixel is pure black/white
    mag_norm = (magnitude - magnitude.min()) / (magnitude.max() - magnitude.min() + 1e-8)

    return mag_norm


# convert 1 channel greyscale data to 3 channels for visualization
def to_three_ch(grey_dataset):
    # checks if batch dimension exists (B, C, H, W), squeeze(0) removes B
    if grey_dataset.dim() == 4:
        grey_dataset = grey_dataset.squeeze(0)

    # repeat the grayscale channel 3 times across the color (C) dimension
    # keeps H, W the same (1, 1)
    grey_3ch = grey_dataset.repeat(3, 1, 1)
    return grey_3ch
class MultiImageSet(Dataset):
    def __init__(self, base_dataset, grey_transform):
        # store information from base dataset and transform
        self.base_dataset = base_dataset
        self.grey_transform = grey_transform
        # preserve class attribute
        self.classes = getattr(base_dataset, 'classes', None)  # default attribute is None

    def __getitem__(self, index):
        # get original data
        original_img, img_label = self.base_dataset[index]

        # get the greyscale image
        grey_img = self.grey_transform(original_img)

        # apply sobel filter
        sobel_img = sobel_filter(grey_img)

        # binarize edges across several thresholds
        thresh = torch.quantile(sobel_img, 0.70)
        binary_img70 = (sobel_img >= thresh).float()

        thresh = torch.quantile(sobel_img, 0.80)
        binary_img80 = (sobel_img >= thresh).float()

        thresh = torch.quantile(sobel_img, 0.90)
        binary_img90 = (sobel_img >= thresh).float()

        # convert all to 3 channel images for visualization
        binary_img70 = to_three_ch(binary_img70)
        binary_img80 = to_three_ch(binary_img80)
        binary_img90 = to_three_ch(binary_img90)
        # return all calculated images plus the label
        return original_img, binary_img70, binary_img80, binary_img90,  img_label

    def __len__(self):
        return len(self.base_dataset)


# set initial transform, to tensor
transform = transforms.Compose([
    transforms.ToTensor(),
])
# load CIFAR-10 dataset
cifar_dataset = torchvision.datasets.CIFAR10(
    root="./data",
    train=True,
    download=True,
    transform=transform  #=None for raw PIL imaages; =transform for to Pytorch Tensor
)

# define second transform, convert to greyscale
grey_transform = transforms.Compose([
    transforms.Grayscale(num_output_channels=1)  # converts to greyscale
])



# load multi-image dataset
# (original, grey, sobel, binary, label)
multi_dataset = MultiImageSet(cifar_dataset, grey_transform)


# get subset of multi_dataset, one sample from each class
# store in sorted dictionary format {int_label:(tensor_tuple)}
image_subset = {}

# iterate through multi_dataset to find unique image for each unique class
for *_, label in multi_dataset:
    int_label = int(label)  # converts tensor label to int
    if int_label not in image_subset:
        image_subset[int_label] = (*_, int_label)  # load image tensors as values

    # stop iteration if one image found for just 4 classes
    if len(image_subset) == 4:
        break

# separate into separate lists for better visualization
orig_list = []
binary_img70_list = []
binary_img80_list = []
binary_img90_list = []
class_list = []

# loop through keys in sorted order
for key in sorted(image_subset.keys()):
    orig, grey, sobel, binary, label = image_subset[key]
    orig_list.append(orig)
    binary_img70_list.append(grey)
    binary_img80_list.append(sobel)
    binary_img90_list.append(binary)
    class_list.append(label)
image_list = orig_list + binary_img70_list + binary_img80_list + binary_img90_list

# check classes in CIFAR-10 dataset
# print(multi_dataset.classes)


# get number of classes
n_classes = len(class_list)
# set values for subplot
fig, axes = plt.subplots(4, n_classes, figsize=(12, 4))

# draw images to subplot from image_list
for i, img in enumerate(image_list):
    # calculate row and column index for each image
    row = i // n_classes  # makes sure items in row don't exceed 10, gives row number
    col = i % n_classes  # gives column position

    img_np = img.permute(1, 2, 0).numpy()  # change from (C,H,W) to (H,W,C)
    axes[row, col].imshow(img_np, cmap="gray")  # default colormap is grey
    axes[row, col].axis("off")

# adds titles only to the first 10 images (top row)
for col in range(n_classes):
    # class_list[col] returns integer to corresponding class
    # multi_dataset.classes[i] uses the integer to return related class name
    axes[0, col].set_title(multi_dataset.classes[class_list[col]], fontsize=10)

plt.tight_layout()
plt.show()