import numpy as np
# install julia / pip install diffeqpy
from diffeqpy import de
import matplotlib.pyplot as plt

# without a time delay, the DDE problem becomes a simple ODE problem
def model_ode(u, p, t):
    c1, c2, c3, c4 = p
    A, B = u

    # no need for history function or to retrieve delayed state
    dA_dt = c1 - c3 * A * B
    dB_dt = c2 * A - c4 * B

    return [dA_dt, dB_dt]

# parameter setup
tspan = (0.0, 200.0)
# no need to define tau
p = (20.0, 0.1, 0.1, 0.1)  # (c1, c2, c3, c4)
u0 = [10.0, 200.0]

# utilizes ODE problem solver instead of DDE
prob = de.ODEProblem(model_ode, u0, tspan, p)
sol = de.solve(prob, de.Tsit5())


t = np.array(sol.t)
u_res = np.stack(sol.u)

plt.figure(figsize=(10, 5))
plt.plot(t, u_res[:, 0], label='A', color='teal', linewidth=2)
plt.plot(t, u_res[:, 1], label='B', color='orange', linewidth=2)

plt.title('Negative Feedback System (A & B) (Tau = 0)')
plt.xlabel('Time')
plt.ylabel('Value')
plt.legend()
plt.grid(True, alpha=0.3)
plt.show()
