import PyQt5.QtWidgets as qtw
import PyQt5.QtGui as qtg
from PyQt5.QtCore import Qt, QPoint, QSize
import sys
import math


# Device class that defines name of device and device appearance
class Device(qtw.QLabel):
    def __init__(self, parent, image_path, name, device_type):
        super().__init__(parent)
        self.name = name
        self.device_type = device_type
        self.status = False  # sets initial status: False = OFF, True = ON

        # checks to see if image_path is valid, then spawns device image to scale
        pixmap = qtg.QPixmap(image_path)
        if not pixmap.isNull():
            pixmap = pixmap.scaled(80, 80, Qt.KeepAspectRatio, Qt.SmoothTransformation)
            self.setPixmap(pixmap)
        self.resize(80, 80)

        # creates boarder around image AND creates image appearance if selected for deleting or connecting
        self.default_style = "border: 1px dashed gray; background: transparent;"  # default
        self.selected_style = "border: 3px solid #e74c3c; background: rgba(231, 76, 60, 0.1);"  # red when can be deleted
        self.on_style = "border: 3px solid #2ecc71; background: rgba(46, 204, 113, 0.2);"  # green when device is ON
        self.update_appearance()
        self.old_pos = None

    # changes device appearance based on whether device is ON or OFF
    def update_appearance(self):
        if self.status:
            self.setStyleSheet(f"QLabel {{ {self.on_style} }}")
        else:
            self.setStyleSheet(f"QLabel {{ {self.default_style} }}")

    # defines whether device is ON or OFF
    def toggle_status(self):
        self.status = not self.status
        self.update_appearance()

    # calculates 'anchor-points' for spawned devices based on device-image edges
    def get_anchors(self):
        r = self.geometry()
        return [
            QPoint(r.x() + r.width() // 2, r.y()),
            QPoint(r.x() + r.width() // 2, r.y() + r.height()),
            QPoint(r.x(), r.y() + r.height() // 2),
            QPoint(r.x() + r.width(), r.y() + r.height() // 2)
        ]

    # determine if device is going to be connected, moved, or selected (can be deleted and prepared for movement)
    def mousePressEvent(self, event):
        # checks to see if connector has been selected
        if self.parent().is_connecting:
            self.parent().start_connection_drag(self)
        else:
            # otherwise, item is selected
            self.parent().select_node(self)
            if event.button() == Qt.LeftButton:
                # gets mouse posiiton in preparation for movement
                self.old_pos = event.pos()

    # behavior that toggles device ON or OFF (double-click)
    def mouseDoubleClickEvent(self, event):
        self.toggle_status()

    # events for when the mouse is moving
    def mouseMoveEvent(self, event):
        # if connecting/draging line, then starts drawing line where mouse moves
        if self.parent().is_dragging_line:
            global_pos = self.mapToParent(event.pos())
            self.parent().handle_drag_move(global_pos)
        # if not connecting, updates image position
        elif self.old_pos:
            delta = event.pos() - self.old_pos
            new_pos = self.pos() + delta
            # checks to see where image is inside right-hand frame
            pr = self.parent().rect()
            x = max(0, min(new_pos.x(), pr.width() - self.width()))
            y = max(0, min(new_pos.y(), pr.height() - self.height()))
            # actually updates image position
            self.move(x, y)
            self.parent().update()

    # if mouse is released while connector is selected (is_dragging_line condition) then keeps line
    def mouseReleaseEvent(self, event):
        if self.parent().is_dragging_line:
            self.parent().handle_drag_release()
        self.old_pos = None  # clears previous value for mouse position to calculate future movements


# connection class defined to handle link logic between two devices
class Connection:
    def __init__(self, start_device, end_device):
        self.start_device = start_device
        self.end_device = end_device
        self.connection_type = "Standard"


# drawing area class defined to define right-hand frame that 'boxes' in devices
class DrawingArea(qtw.QFrame):
    def __init__(self):
        super().__init__()
        # initial parameters for drawing area
        self.is_connecting = False
        self.is_dragging_line = False
        self.start_node = None
        self.target_node = None
        self.selected_node = None
        self.selected_line_idx = -1  # ensures no line is being drawn upon app opening
        self.connections = []  # intilaizes array for connecting objects/components
        self.mouse_pos = QPoint(0, 0)  # initilizes mouse position on frame for drawing area

        # sets frame styple for right-hand frame
        self.setStyleSheet("QFrame { background-color: white; border: 3px solid #555; }")
        self.setMouseTracking(True)  # ensure frame tracks mouse movement
        self.setFocusPolicy(Qt.StrongFocus)  # ensures delete key works on objects in Drawing Area

    # defines behavior when an object is selected in the Drawing Area
    def select_node(self, node):
        # if node is selected, then if Drawing Area or another node is selected, previous sets node to 'default' appearance
        if self.selected_node:
            self.selected_node.update_appearance()  # updates nodes appearance to 'default'
        self.selected_node = node
        if node:
            # visulally updates node acording to selection status if node is clicked
            node.setStyleSheet(f"QLabel {{{node.selected_style}}}")
        self.selected_line_idx = -1  # returns line to 'default' appearance (if line was highlighed rpreviously)
        self.update()

    # defines behavior for creating line between node
    def start_connection_drag(self, node):
        self.is_dragging_line = True
        self.start_node = node
        # sets line stlye for connecting line
        node.setStyleSheet("QLabel { border: 3px solid #3498db; }")

    # defines logic for drawing line between nodes
    def handle_drag_move(self, pos):
        self.mouse_pos = pos  # checks position, then updates
        self.update()

    # defines logic that handles making connection when connecting to other device
    def handle_drag_release(self):
        found_target = None  # default value for found_target
        for child in self.findChildren(Device):  # interates through all devices in frame
            # if device is not current device, and mouse is released inside of valid node, then found_target is set to valid node
            if child != self.start_node and child.geometry().contains(self.mouse_pos):
                found_target = child
                break

        # if mouse released on valid node (device), creates connection
        if found_target and self.start_node:
            self.connections.append(Connection(self.start_node, found_target))

        # resets values
        if self.start_node: self.start_node.update_appearance()  # changes node from blue highlight, back to default
        self.is_dragging_line = False
        self.is_connecting = False
        self.start_node = None
        self.setCursor(Qt.ArrowCursor)  # changes cursor/mouse back to normal icon
        self.update()

    # re-calculates best anchor points between connecting objects depending on objects position in frame
    def get_best_anchors(self, d1, d2):
        a1, a2 = d1.get_anchors(), d2.get_anchors()  # get 4 anchor points from each connecting device
        best_p1, best_p2 = a1[0], a2[0]  # set best achor points to default 'first' anchor points
        min_dist = float('inf')  # set min dist to infinity by default
        # loops through all anchor points from each device to calculate optimal achors
        for p1 in a1:
            for p2 in a2:
                # uses distance formula via pythagorean theorem (hypotenuse)
                d = math.hypot(p1.x() - p2.x(), p1.y() - p2.y())
                # updates d with the best/minimum distance
                if d < min_dist:
                    min_dist, best_p1, best_p2 = d, p1, p2
        # after iteration, returns best anchor points
        return best_p1, best_p2

    # setup for any objects to be drawn/painted to the screen
    def paintEvent(self, event):
        super().paintEvent(event)
        painter = qtg.QPainter(self)  # sets up paintbrush
        painter.setRenderHint(qtg.QPainter.Antialiasing)  # sets brush to smooth

        # logic defining painting connections between devices
        for i, conn in enumerate(self.connections):
            p1, p2 = self.get_best_anchors(conn.start_device, conn.end_device)  # gets achors from deice
            # logic for physically drawing line in frame
            color = qtg.QColor("#e74c3c") if i == self.selected_line_idx else Qt.black
            width = 5 if i == self.selected_line_idx else 3
            # paints the 'permanent' line between existing connections
            painter.setPen(qtg.QPen(color, width, Qt.SolidLine))
            painter.drawLine(p1, p2)

        # paints the 'temporary' line between when connecting devices
        if self.is_dragging_line:
            painter.setPen(qtg.QPen(Qt.gray, 2, Qt.DashLine))
            painter.drawLine(self.start_node.geometry().center(), self.mouse_pos)

    # mouse press events that trigger paint events
    def mousePressEvent(self, event):
        self.select_node(None)
        self.selected_line_idx = -1  # turns lines back to default setting if Drawing Area is selected
        for i, conn in enumerate(self.connections):
            # recalculates best anchors while mouse is being pressed (relevent when mouse is moving)
            p1, p2 = self.get_best_anchors(conn.start_device, conn.end_device)

            # checks if mouse is near start of the line (p1)
            if math.hypot(event.pos().x() - p1.x(), event.pos().y() - p1.y()) < 15:  # pixel breadth of 15 used
                # logic for breaking connection
                re_anchor = conn.end_device
                self.connections.pop(i)
                # restarts connecting behavior
                self.start_connection_drag(re_anchor)
                self.mouse_pos = event.pos()  # re-syncs current position
                self.update()
                return

            # checks if mouse is near start of the line (p1)
            elif math.hypot(event.pos().x() - p2.x(), event.pos().y() - p2.y()) < 15:
                # same as logic for p1
                re_anchor = conn.start_device
                self.connections.pop(i)
                self.start_connection_drag(re_anchor)
                self.mouse_pos = event.pos()
                self.update()
                return

            # behavior that selects line if mouse is between two ends of line
            if self.dist_to_segment(event.pos(), p1, p2) < 10:
                self.selected_line_idx = i
                break

        self.update()

    # logic defining determining how close mouse is to any section on the line
    def dist_to_segment(self, p, a, b):
        # sets the change in x and y between two endpoints on wire-line
        dx = b.x() - a.x()
        dy = b.y() - a.y()
        # determines squared length of the line (easier for future calculations)
        L2 = (dx) ** 2 + (dy) ** 2
        # if sq length is zero, passes line as if a dot (is a dot)
        if L2 == 0: return math.hypot(p.x() - a.x(), p.y() - a.y())
        # caculcates dot product between line distance, and distance between mouse and line, as a percentage (when divided by L2)
        t = max(0, min(1, ((p.x() - a.x()) * (dx) + (p.y() - a.y()) * (dy)) / L2))  # clips at max 1, min 0
        # calculates projection point, or point on wire closest to mouse
        proj = QPoint(int(a.x() + t * (dx)), int(a.y() + t * (dy)))  # round to int because pixel must be whole number
        # returns the distance between mouse and closest point with pythagorean formula
        return math.hypot(p.x() - proj.x(), p.y() - proj.y())

    # defines behavior deleting objects in frame
    def keyPressEvent(self, event):
        if event.key() == Qt.Key_Delete:
            if self.selected_line_idx != -1:  # checks to see if line is highlighted
                self.connections.pop(self.selected_line_idx)  # removes line from connections array
                self.selected_line_idx = -1  # resets index to default
            elif self.selected_node:
                # defines waterfall behavior for deleted device (deletes associated connections)
                self.connections = [c for c in self.connections if
                                    c.start_device != self.selected_node and c.end_device != self.selected_node]
                # deletes node/device from screen and memory
                self.selected_node.deleteLater()
                self.selected_node = None  # resets selected back to None
            self.update()


# class defining main display of application
class MainWindow(qtw.QWidget):
    def __init__(self):
        super().__init__()
        # set window layout
        self.setWindowTitle("Task-3: Build a visual network of connected devices in a GUI")
        self.setGeometry(0, 0, 1400, 900)
        layout = qtw.QHBoxLayout(self)

        # configures toolbar to left and items in toolbar
        self.toolBar = qtw.QToolBar()
        self.toolBar.setOrientation(Qt.Vertical)
        self.toolBar.setIconSize(QSize(60, 60))
        self.toolBar.setToolButtonStyle(Qt.ToolButtonTextUnderIcon)
        layout.addWidget(self.toolBar)

        # configures frame to right of toolbar
        self.drawing_area = DrawingArea()
        layout.addWidget(self.drawing_area, stretch=1)  # allows Drawing Area frame to stretch to rest of window

        # defines devices in toolbox
        self.setup_tool("Servo Motor", "images/servo_motor.png", "Motor")
        self.setup_tool("Brushless DC Motor", "images/dc_brushless_motor.png", "Motor")
        self.setup_tool("Relay", "images/relay_act.png", "Actuator")
        self.setup_tool("Solenoid", "images/solenoid_act.png", "Actuator")
        self.setup_tool("Light Sensor", "images/light_sensor.png", "Sensor")
        self.setup_tool("Ultrasonic Sensor", "images/ultrasonic_sensor.png", "Sensor")
        self.setup_tool("Motion Sensor", "images/motion_sensor.png", "Sensor")
        self.toolBar.addSeparator()
        self.setup_tool("2-Wire Connector", "images/2_wire_connector", "Connector")
        self.setup_tool("4-Wire Connector", "images/4_wire_connector.png", "Connector")

    # makes actionable buttons out of items in toolbar
    def setup_tool(self, name, path, dev_type):
        action = qtw.QAction(qtg.QIcon(path), name, self)
        # if item is connector, toggles connector actions to prepare for line drawing
        if dev_type == "Connector":
            action.triggered.connect(self.toggle_connector)
        else:
            # otherwise, spawns device onto Draw Area window
            action.triggered.connect(lambda: self.spawn_device(path, name, dev_type))
        self.toolBar.addAction(action)

    # defines logic that forms confirms process for connecting devices
    def toggle_connector(self):
        self.drawing_area.is_connecting = True
        self.drawing_area.setCursor(Qt.CrossCursor)  # changes cursor to cross

    # defines logic for spawning devices onto Draw Area window
    def spawn_device(self, path, name, dev_type):
        # selects specific device
        dev = Device(self.drawing_area, path, name, dev_type)
        dev.show()
        # sets default position for device to spawn in
        dev.move(200, 200)


# start for application
if __name__ == '__main__':
    app = qtw.QApplication(sys.argv)
    ex = MainWindow()
    ex.show()
    sys.exit(app.exec_())
